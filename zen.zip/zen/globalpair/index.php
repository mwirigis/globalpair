<?php
/**
 * GlobePair - Main Entry Point
 */

require __DIR__ . '/config.php';
require __DIR__ . '/helpers.php';
require __DIR__ . '/payments.php';

 $action = $_GET['action'] ?? 'home';

// ==================== M-PESA CALLBACK HANDLER ====================
if ($action === 'mpesa_callback') {
    $rawData = file_get_contents('php://input');
    $logFile = __DIR__ . '/logs/mpesa_callback.log';
    
    file_put_contents($logFile, date('Y-m-d H:i:s') . " - Received: " . $rawData . "\n\n", FILE_APPEND);
    
    $data = json_decode($rawData, true);

    if (isset($data['Body']['stkCallback'])) {
        $callback = $data['Body']['stkCallback'];
        $checkoutId = $callback['CheckoutRequestID'] ?? null;
        $resultCode = $callback['ResultCode'] ?? 1;
        
        if ($checkoutId) {
            $payment = R::findOne('payment', 'checkout_request_id = ?', [$checkoutId]);
            
            if (!$payment) {
                $payment = R::findOne('messagepayment', 'checkout_request_id = ?', [$checkoutId]);
            }
            
            if ($payment && $payment->id) {
                if ($resultCode == 0) {
                    $mpesaReceipt = '';
                    if (isset($callback['CallbackMetadata']['Item'])) {
                        foreach ($callback['CallbackMetadata']['Item'] as $item) {
                            if ($item['Name'] == 'MpesaReceiptNumber') {
                                $mpesaReceipt = $item['Value'];
                            }
                        }
                    }
                    
                    $payment->status = 'completed';
                    $payment->mpesa_receipt = $mpesaReceipt;
                    $payment->completed_at = date('Y-m-d H:i:s');
                    
                    $isPremium = (isset($payment->payment_type) && $payment->payment_type == 'premium');
                    
                    R::store($payment);
                    
                    if ($isPremium) {
                        $user = R::load('user', $payment->user_id);
                        if ($user->id) {
                            $user->user_role = 'premium';
                            $user->premium_until = date('Y-m-d', strtotime('+30 days'));
                            R::store($user);
                        }
                    }
                    file_put_contents($logFile, date('Y-m-d H:i:s') . " - SUCCESS: Receipt {$mpesaReceipt}\n\n", FILE_APPEND);
                } else {
                    $payment->status = 'failed';
                    R::store($payment);
                    file_put_contents($logFile, date('Y-m-d H:i:s') . " - FAILED: Code {$resultCode}\n\n", FILE_APPEND);
                }
            } else {
                file_put_contents($logFile, date('Y-m-d H:i:s') . " - WARNING: CheckoutID not found in DB.\n\n", FILE_APPEND);
            }
        }
    } else {
        file_put_contents($logFile, date('Y-m-d H:i:s') . " - ERROR: Invalid callback format.\n\n", FILE_APPEND);
    }

    http_response_code(200);
    echo json_encode(['ResultCode' => 0, 'ResultDesc' => 'Accepted']);
    exit;
}

 $current_user = getCurrentUser();
 $page_title = 'GlobePair - Find Your Perfect Match';

// Initialize database on first run
if (!file_exists(DB_PATH)) {
    initializeDatabase();
}

// ==================== HANDLE POST ACTIONS ====================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    if (isset($_POST['action']) && $_POST['action'] === 'login') {
        $email = sanitize($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        
        $user = R::findOne('user', 'email = ?', [$email]);
        
        if ($user && password_verify($password, $user->password)) {
            if ($user->status !== 'active') {
                $_SESSION['error'] = 'Your account has been deactivated. Please contact support.';
            } else {
                $_SESSION['user_id'] = $user->id;
                $user->last_login = date('Y-m-d H:i:s');
                R::store($user);
                $_SESSION['success'] = 'Welcome back, ' . $user->first_name . '!';
                header('Location: ?action=dashboard');
                exit;
            }
        } else {
            $_SESSION['error'] = 'Invalid email or password';
        }
    }
    
    if (isset($_POST['action']) && $_POST['action'] === 'register') {
        $email = sanitize($_POST['email'] ?? '');
        $first_name = sanitize($_POST['first_name'] ?? '');
        $last_name = sanitize($_POST['last_name'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        $city = sanitize($_POST['city'] ?? '');
        $birth_date = $_POST['birth_date'] ?? '';
        $gender = sanitize($_POST['gender'] ?? '');
        $bio = sanitize($_POST['bio'] ?? '');
        
        $errors = [];
        
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Invalid email address';
        }
        if (strlen($password) < 6) {
            $errors[] = 'Password must be at least 6 characters';
        }
        if ($password !== $confirm_password) {
            $errors[] = 'Passwords do not match';
        }
        if (empty($first_name) || empty($last_name)) {
            $errors[] = 'First and last name are required';
        }
        
        if (empty($errors)) {
            $existing = R::findOne('user', 'email = ?', [$email]);
            if ($existing) {
                $errors[] = 'Email already registered';
            }
        }
        
        $profile_image = null;
        if (isset($_FILES['profile_photo']) && $_FILES['profile_photo']['error'] !== UPLOAD_ERR_NO_FILE) {
            $upload_result = handlePhotoUpload($_FILES['profile_photo']);
            if (is_array($upload_result) && isset($upload_result['error'])) {
                $errors[] = $upload_result['error'];
            } elseif (is_string($upload_result)) {
                $profile_image = $upload_result;
            }
        }
        
        if (empty($errors)) {
            $user = R::dispense('user');
            $user->email = $email;
            $user->password = password_hash($password, PASSWORD_BCRYPT);
            $user->first_name = $first_name;
            $user->last_name = $last_name;
            $user->city = $city;
            $user->birth_date = $birth_date;
            $user->gender = $gender;
            $user->bio = $bio;
            $user->profile_image = $profile_image;
            $user->user_role = 'regular';
            $user->is_admin = 0;
            $user->status = 'active';
            $user->created_at = date('Y-m-d H:i:s');
            $user->updated_at = date('Y-m-d H:i:s');
            
            $user_id = R::store($user);
            
            if ($profile_image) {
                $old_path = __DIR__ . '/' . $profile_image;
                $extension = pathinfo($profile_image, PATHINFO_EXTENSION);
                $new_filename = 'user_' . $user_id . '_' . time() . '.' . $extension;
                $new_path = UPLOAD_DIR . $new_filename;
                
                if (rename($old_path, $new_path)) {
                    $user->profile_image = 'uploads/' . $new_filename;
                    R::store($user);
                }
            }
            
            $_SESSION['success'] = 'Registration successful! Please login.';
            header('Location: ?action=login');
            exit;
        } else {
            if ($profile_image && file_exists(__DIR__ . '/' . $profile_image)) {
                unlink(__DIR__ . '/' . $profile_image);
            }
            $_SESSION['errors'] = $errors;
            $_SESSION['form_data'] = [
                'email' => $email,
                'first_name' => $first_name,
                'last_name' => $last_name,
                'city' => $city,
                'birth_date' => $birth_date,
                'gender' => $gender,
                'bio' => $bio
            ];
        }
    }
    
    if (isset($_POST['action']) && $_POST['action'] === 'update_profile') {
        requireLogin();
        
        $current_user->first_name = sanitize($_POST['first_name'] ?? '');
        $current_user->last_name = sanitize($_POST['last_name'] ?? '');
        $current_user->city = sanitize($_POST['city'] ?? '');
        $current_user->bio = sanitize($_POST['bio'] ?? '');
        $current_user->birth_date = $_POST['birth_date'] ?? '';
        $current_user->gender = sanitize($_POST['gender'] ?? '');
        $current_user->updated_at = date('Y-m-d H:i:s');
        
        R::store($current_user);
        $_SESSION['success'] = 'Profile updated successfully!';
        header('Location: ?action=dashboard');
        exit;
    }
    
    if (isset($_POST['action']) && $_POST['action'] === 'send_message') {
        requireLogin();
        
        $to_user_id = intval($_POST['to_user_id'] ?? 0);
        $content = sanitize($_POST['content'] ?? '');
        
        $to_user = R::load('user', $to_user_id);
        
        if ($to_user_id && !empty($content) && $to_user->id) {
            if (!canSendMessage($current_user, $to_user)) {
                $_SESSION['error'] = 'Payment required to send messages';
                $_SESSION['message_redirect'] = $to_user_id;
                header('Location: ?action=payment_required');
                exit;
            }
            
            $message = R::dispense('message');
            $message->from_user_id = $current_user->id;
            $message->to_user_id = $to_user_id;
            $message->content = $content;
            $message->is_read = 0;
            $message->created_at = date('Y-m-d H:i:s');
            
            R::store($message);
            $_SESSION['success'] = 'Message sent!';
            header('Location: ?action=chat&user_id=' . $to_user_id);
            exit;
        }
    }
    
    if (isset($_POST['action']) && $_POST['action'] === 'add_favorite') {
        requireLogin();
        
        $favorite_user_id = intval($_POST['favorite_user_id'] ?? 0);
        
        if ($favorite_user_id && $favorite_user_id !== $current_user->id) {
            $existing = R::findOne('favorite', 'user_id = ? AND favorite_user_id = ?', [$current_user->id, $favorite_user_id]);
            
            if (!$existing) {
                $favorite = R::dispense('favorite');
                $favorite->user_id = $current_user->id;
                $favorite->favorite_user_id = $favorite_user_id;
                $favorite->created_at = date('Y-m-d H:i:s');
                R::store($favorite);
                $_SESSION['success'] = 'Added to favorites!';
            }
        }
        
        $redirect = $_POST['redirect'] ?? 'view_profile';
        if ($redirect === 'home') {
            header('Location: ?action=home#members');
        } else {
            header('Location: ?action=view_profile&id=' . $favorite_user_id);
        }
        exit;
    }
    
    if (isset($_POST['action']) && $_POST['action'] === 'upgrade_premium') {
        requireLogin();
        
        $phone = preg_replace('/[^0-9]/', '', $_POST['phone'] ?? '');
        
        if (strlen($phone) === 12 && substr($phone, 0, 3) === '254') {
            $reference = 'PREM_' . $current_user->id . '_' . time();
            
            $result = initiateMpesaSTKPush($phone, PREMIUM_PRICE, $reference);
            
            if ($result['success']) {
                $payment = R::dispense('payment');
                $payment->user_id = $current_user->id;
                $payment->phone = $phone;
                $payment->amount = PREMIUM_PRICE;
                $payment->status = 'pending';
                $payment->mpesa_receipt = null;
                $payment->checkout_request_id = $result['checkout_request_id'];
                $payment->merchant_request_id = $result['merchant_request_id'];
                $payment->reference = $reference;
                $payment->payment_type = 'premium';
                $payment->created_at = date('Y-m-d H:i:s');
                R::store($payment);
                
                $_SESSION['success'] = 'M-Pesa prompt sent to your phone. Please enter your PIN to complete payment.';
                header('Location: ?action=payment_status&id=' . $payment->id);
                exit;
            } else {
                $_SESSION['error'] = 'M-Pesa error: ' . $result['error'];
            }
        } else {
            $_SESSION['error'] = 'Invalid phone number format. Use 254712345678';
        }
        header('Location: ?action=premium');
        exit;
    }
    
    if (isset($_POST['action']) && $_POST['action'] === 'pay_message_mpesa') {
        requireLogin();
        
        $phone = preg_replace('/[^0-9]/', '', $_POST['phone'] ?? '');
        $to_user_id = intval($_POST['to_user_id'] ?? 0);
        
        if (strlen($phone) === 12 && substr($phone, 0, 3) === '254' && $to_user_id) {
            $reference = 'MSG_' . $current_user->id . '_' . time();
            
            $result = initiateMpesaSTKPush($phone, MESSAGE_FEE_KES, $reference);
            
            if ($result['success']) {
                $payment = R::dispense('messagepayment');
                $payment->user_id = $current_user->id;
                $payment->phone = $phone;
                $payment->amount = MESSAGE_FEE_KES;
                $payment->currency = 'KES';
                $payment->status = 'pending';
                $payment->mpesa_receipt = null;
                $payment->checkout_request_id = $result['checkout_request_id'];
                $payment->merchant_request_id = $result['merchant_request_id'];
                $payment->reference = $reference;
                $payment->to_user_id = $to_user_id;
                $payment->payment_method = 'mpesa';
                $payment->expires_at = date('Y-m-d H:i:s', strtotime('+24 hours'));
                $payment->created_at = date('Y-m-d H:i:s');
                R::store($payment);
                
                $_SESSION['success'] = 'M-Pesa prompt sent! Enter your PIN to complete KES ' . MESSAGE_FEE_KES . ' payment.';
                header('Location: ?action=payment_status&type=message&id=' . $payment->id);
                exit;
            } else {
                $_SESSION['error'] = 'M-Pesa error: ' . $result['error'];
            }
        } else {
            $_SESSION['error'] = 'Invalid phone number format';
        }
        header('Location: ?action=payment_required&user_id=' . $to_user_id);
        exit;
    }
    
    if (isset($_POST['action']) && $_POST['action'] === 'pay_message_paypal') {
        requireLogin();
        
        $to_user_id = intval($_POST['to_user_id'] ?? 0);
        
        if ($to_user_id) {
            $reference = 'MSG_' . $current_user->id . '_' . time();
            
            $result = createPayPalOrder(MESSAGE_FEE_USD, $reference);
            
            if ($result['success']) {
                $payment = R::dispense('messagepayment');
                $payment->user_id = $current_user->id;
                $payment->amount = MESSAGE_FEE_USD;
                $payment->currency = 'USD';
                $payment->status = 'pending';
                $payment->paypal_order_id = $result['order_id'];
                $payment->reference = $reference;
                $payment->to_user_id = $to_user_id;
                $payment->payment_method = 'paypal';
                $payment->expires_at = date('Y-m-d H:i:s', strtotime('+24 hours'));
                $payment->created_at = date('Y-m-d H:i:s');
                R::store($payment);
                
                if ($result['approve_url']) {
                    header('Location: ' . $result['approve_url']);
                    exit;
                }
            } else {
                $_SESSION['error'] = 'PayPal error: ' . $result['error'];
            }
        }
        header('Location: ?action=payment_required&user_id=' . $to_user_id);
        exit;
    }
    
    if (isset($_POST['action']) && $_POST['action'] === 'toggle_status') {
        requireAdmin();
        
        $user_id = intval($_POST['user_id'] ?? 0);
        $new_status = sanitize($_POST['new_status'] ?? 'active');
        
        if ($user_id) {
            $user = R::load('user', $user_id);
            if ($user->id && !$user->is_admin) {
                $user->status = $new_status;
                $user->updated_at = date('Y-m-d H:i:s');
                R::store($user);
                $_SESSION['success'] = 'User status updated to ' . $new_status;
            }
        }
        header('Location: ?action=admin');
        exit;
    }
}

// Handle PayPal callback
if ($action === 'paypal_success') {
    requireLogin();
    
    $payment_id = intval($_GET['payment_id'] ?? 0);
    $token = sanitize($_GET['token'] ?? '');
    
    $payment = R::load('messagepayment', $payment_id);
    
    if ($payment->id && $payment->status === 'pending' && $payment->payment_method === 'paypal') {
        $result = capturePayPalOrder($payment->paypal_order_id);
        
        if ($result['success']) {
            $payment->status = 'completed';
            $payment->paypal_transaction_id = $result['transaction_id'];
            $payment->completed_at = date('Y-m-d H:i:s');
            R::store($payment);
            
            $_SESSION['success'] = 'Payment successful! You can now send messages.';
            header('Location: ?action=chat&user_id=' . $payment->to_user_id);
            exit;
        } else {
            $_SESSION['error'] = 'PayPal capture failed: ' . $result['error'];
        }
    }
    header('Location: ?action=dashboard');
    exit;
}

if ($action === 'paypal_cancel') {
    $_SESSION['error'] = 'Payment cancelled';
    header('Location: ?action=dashboard');
    exit;
}

if ($action === 'logout') {
    session_destroy();
    header('Location: ?action=home');
    exit;
}

// Handle chat redirect
if ($action === 'chat_redirect') {
    $redirect_user_id = intval($_GET['user_id'] ?? 0);
    if (!$current_user) {
        $_SESSION['chat_redirect'] = $redirect_user_id;
        header('Location: ?action=register');
        exit;
    } else {
        header('Location: ?action=chat&user_id=' . $redirect_user_id);
        exit;
    }
}

// Retrieve form data for repopulating on error
 $form_data = $_SESSION['form_data'] ?? [];
unset($_SESSION['form_data']);

// ==================== INCLUDE PAGE ====================
include __DIR__ . '/header.php';

switch ($action) {
    case 'home':
        include __DIR__ . '/home.php';
        break;
    case 'login':
        include __DIR__ . '/login.php';
        break;
    case 'register':
        include __DIR__ . '/register.php';
        break;
    case 'payment_required':
        include __DIR__ . '/payment_required.php';
        break;
    case 'payment_status':
        include __DIR__ . '/payment_status.php';
        break;
    case 'dashboard':
        include __DIR__ . '/dashboard.php';
        break;
    case 'discover':
        include __DIR__ . '/discover.php';
        break;
    case 'view_profile':
        include __DIR__ . '/view_profile.php';
        break;
    case 'chat':
        include __DIR__ . '/chat.php';
        break;
    case 'favorites':
        include __DIR__ . '/favorites.php';
        break;
    case 'my_payments':
        include __DIR__ . '/my_payments.php';
        break;
    case 'edit_profile':
        include __DIR__ . '/edit_profile.php';
        break;
    case 'premium':
        include __DIR__ . '/premium.php';
        break;
    case 'admin':
        include __DIR__ . '/admin.php';
        break;
    default:
        include __DIR__ . '/home.php';
        break;
}

include __DIR__ . '/footer.php';