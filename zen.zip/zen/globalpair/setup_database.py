#!/usr/bin/env python3
"""
GlobePair - Database Setup
Creates globepair.db with all tables, admin user, and sample data.
Usage: python3 setup_database.py
"""

import os
import sqlite3
import hashlib
from datetime import datetime, timedelta

try:
    import bcrypt
except ImportError:
    print("ERROR: bcrypt module is required.")
    print("Install it with: pip3 install bcrypt")
    exit(1)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "globepair.db")

# ==================== CONFIG ====================
ADMIN_EMAIL = "admin@globepair.com"
ADMIN_PASSWORD = "Kenya@254"

SAMPLE_USERS = [
    {
        "email": "alice@globepair.com",
        "password": "alice123",
        "first_name": "Alice",
        "last_name": "Johnson",
        "city": "Nairobi",
        "bio": "Adventure lover & coffee enthusiast. Looking for someone who enjoys outdoor activities and good conversations.",
        "birth_date": "1995-03-15",
        "gender": "female",
        "user_role": "premium",
    },
    {
        "email": "bob@globepair.com",
        "password": "bob123",
        "first_name": "Bob",
        "last_name": "Smith",
        "city": "Nairobi",
        "bio": "Software engineer & photography hobbyist. Love capturing beautiful moments.",
        "birth_date": "1993-07-22",
        "gender": "male",
        "user_role": "premium",
    },
    {
        "email": "carol@globepair.com",
        "password": "carol123",
        "first_name": "Carol",
        "last_name": "Williams",
        "city": "Mombasa",
        "bio": "Yoga instructor & beach lover. Life is better at the beach!",
        "birth_date": "1998-11-08",
        "gender": "female",
        "user_role": "regular",
    },
    {
        "email": "david@globepair.com",
        "password": "david123",
        "first_name": "David",
        "last_name": "Brown",
        "city": "Kisumu",
        "bio": "Entrepreneur & traveler. Been to 15 countries and counting.",
        "birth_date": "1991-05-30",
        "gender": "male",
        "user_role": "regular",
    },
    {
        "email": "emma@globepair.com",
        "password": "emma123",
        "first_name": "Emma",
        "last_name": "Davis",
        "city": "Nairobi",
        "bio": "Graphic designer & art lover. Creativity is my superpower.",
        "birth_date": "1996-09-14",
        "gender": "female",
        "user_role": "premium",
    },
    {
        "email": "frank@globepair.com",
        "password": "frank123",
        "first_name": "Frank",
        "last_name": "Miller",
        "city": "Nakuru",
        "bio": "Gym enthusiast & movie buff. Looking for my co-star in life.",
        "birth_date": "1994-02-20",
        "gender": "male",
        "user_role": "regular",
    },
    {
        "email": "grace@globepair.com",
        "password": "grace123",
        "first_name": "Grace",
        "last_name": "Wanjiku",
        "city": "Nairobi",
        "bio": "Teacher by day, chef by night. Love trying new recipes.",
        "birth_date": "1997-06-12",
        "gender": "female",
        "user_role": "premium",
    },
    {
        "email": "henry@globepair.com",
        "password": "henry123",
        "first_name": "Henry",
        "last_name": "Ochieng",
        "city": "Mombasa",
        "bio": "Marine biologist. The ocean is my second home.",
        "birth_date": "1992-12-05",
        "gender": "male",
        "user_role": "regular",
    },
]


def hash_password(plain_password):
    """Hash password using bcrypt, compatible with PHP's password_hash(PASSWORD_BCRYPT)."""
    password_bytes = plain_password.encode("utf-8")
    salt = bcrypt.gensalt(rounds=10)
    hashed = bcrypt.hashpw(password_bytes, salt)
    # PHP expects $2y$ prefix, Python bcrypt uses $2b$. Swap it for full compatibility.
    return hashed.decode("utf-8").replace("$2b$", "$2y$", 1)


def create_tables(conn):
    """Create all application tables."""
    cur = conn.cursor()

    cur.executescript("""
        CREATE TABLE IF NOT EXISTS user (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL,
            first_name TEXT NOT NULL DEFAULT '',
            last_name TEXT NOT NULL DEFAULT '',
            city TEXT NOT NULL DEFAULT '',
            bio TEXT NOT NULL DEFAULT '',
            birth_date TEXT NOT NULL DEFAULT '',
            gender TEXT NOT NULL DEFAULT '',
            profile_image TEXT DEFAULT NULL,
            user_role TEXT NOT NULL DEFAULT 'regular',
            is_admin INTEGER NOT NULL DEFAULT 0,
            status TEXT NOT NULL DEFAULT 'active',
            last_login TEXT DEFAULT NULL,
            premium_until TEXT DEFAULT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS message (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            from_user_id INTEGER NOT NULL,
            to_user_id INTEGER NOT NULL,
            content TEXT NOT NULL,
            is_read INTEGER NOT NULL DEFAULT 0,
            read_at TEXT DEFAULT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY (from_user_id) REFERENCES user(id),
            FOREIGN KEY (to_user_id) REFERENCES user(id)
        );

        CREATE TABLE IF NOT EXISTS favorite (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            favorite_user_id INTEGER NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES user(id),
            FOREIGN KEY (favorite_user_id) REFERENCES user(id),
            UNIQUE(user_id, favorite_user_id)
        );

        CREATE TABLE IF NOT EXISTS payment (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            phone TEXT DEFAULT NULL,
            amount REAL NOT NULL DEFAULT 0,
            status TEXT NOT NULL DEFAULT 'pending',
            mpesa_receipt TEXT DEFAULT NULL,
            checkout_request_id TEXT DEFAULT NULL,
            merchant_request_id TEXT DEFAULT NULL,
            reference TEXT DEFAULT NULL,
            payment_type TEXT DEFAULT NULL,
            created_at TEXT NOT NULL,
            completed_at TEXT DEFAULT NULL,
            FOREIGN KEY (user_id) REFERENCES user(id)
        );

        CREATE TABLE IF NOT EXISTS messagepayment (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            phone TEXT DEFAULT NULL,
            amount REAL NOT NULL DEFAULT 0,
            currency TEXT NOT NULL DEFAULT 'KES',
            status TEXT NOT NULL DEFAULT 'pending',
            mpesa_receipt TEXT DEFAULT NULL,
            checkout_request_id TEXT DEFAULT NULL,
            merchant_request_id TEXT DEFAULT NULL,
            reference TEXT DEFAULT NULL,
            to_user_id INTEGER DEFAULT NULL,
            payment_method TEXT DEFAULT NULL,
            paypal_order_id TEXT DEFAULT NULL,
            paypal_transaction_id TEXT DEFAULT NULL,
            expires_at TEXT DEFAULT NULL,
            created_at TEXT NOT NULL,
            completed_at TEXT DEFAULT NULL,
            FOREIGN KEY (user_id) REFERENCES user(id),
            FOREIGN KEY (to_user_id) REFERENCES user(id)
        );

        CREATE INDEX IF NOT EXISTS idx_message_from ON message(from_user_id);
        CREATE INDEX IF NOT EXISTS idx_message_to ON message(to_user_id);
        CREATE INDEX IF NOT EXISTS idx_favorite_user ON favorite(user_id);
        CREATE INDEX IF NOT EXISTS idx_favorite_target ON favorite(favorite_user_id);
        CREATE INDEX IF NOT EXISTS idx_payment_user ON payment(user_id);
        CREATE INDEX IF NOT EXISTS idx_payment_status ON payment(status);
        CREATE INDEX IF NOT EXISTS idx_msgpay_user ON messagepayment(user_id);
        CREATE INDEX IF NOT EXISTS idx_msgpay_status ON messagepayment(status);
        CREATE INDEX IF NOT EXISTS idx_msgpay_checkout ON messagepayment(checkout_request_id);
        CREATE INDEX IF NOT EXISTS idx_pay_checkout ON payment(checkout_request_id);
    """)

    conn.commit()
    print("  [OK] Tables created")


def insert_admin(conn):
    """Insert the admin user."""
    cur = conn.cursor()

    # Check if admin already exists
    cur.execute("SELECT id FROM user WHERE email = ?", (ADMIN_EMAIL,))
    if cur.fetchone():
        print(f"  [SKIP] Admin user already exists ({ADMIN_EMAIL})")
        return

    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    hashed = hash_password(ADMIN_PASSWORD)

    cur.execute("""
        INSERT INTO user (email, password, first_name, last_name, city, bio, birth_date,
                          gender, user_role, is_admin, status, premium_until, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        ADMIN_EMAIL,
        hashed,
        "Admin",
        "User",
        "Nairobi",
        "Platform Administrator",
        "1990-01-01",
        "other",
        "premium",
        1,
        "active",
        None,
        now,
        now,
    ))

    conn.commit()
    print(f"  [OK] Admin user created ({ADMIN_EMAIL} / {ADMIN_PASSWORD})")


def insert_sample_users(conn):
    """Insert sample users for testing."""
    cur = conn.cursor()
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    inserted = 0
    skipped = 0

    for user in SAMPLE_USERS:
        cur.execute("SELECT id FROM user WHERE email = ?", (user["email"],))
        if cur.fetchone():
            print(f"  [SKIP] {user['email']} (already exists)")
            skipped += 1
            continue

        hashed = hash_password(user["password"])

        cur.execute("""
            INSERT INTO user (email, password, first_name, last_name, city, bio, birth_date,
                              gender, user_role, is_admin, status, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            user["email"],
            hashed,
            user["first_name"],
            user["last_name"],
            user["city"],
            user["bio"],
            user["birth_date"],
            user["gender"],
            user["user_role"],
            0,
            "active",
            now,
            now,
        ))

        inserted += 1
        print(f"  [OK] {user['email']} / {user['password']}")

    conn.commit()
    print(f"  Sample users: {inserted} created, {skipped} skipped")


def insert_sample_messages(conn):
    """Insert sample chat messages between users for testing."""
    cur = conn.cursor()

    # Check if messages already exist
    cur.execute("SELECT COUNT(*) FROM message")
    if cur.fetchone()[0] > 0:
        print("  [SKIP] Sample messages already exist")
        return

    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Get user IDs
    cur.execute("SELECT id, email FROM user WHERE is_admin = 0 ORDER BY id")
    users = {row[1]: row[0] for row in cur.fetchall()}

    sample_conversations = [
        (users.get("alice@globepair.com"), users.get("bob@globepair.com"), "Hey Bob! I saw your photos from Mount Kenya. Amazing!", 0),
        (users.get("bob@globepair.com"), users.get("alice@globepair.com"), "Thanks Alice! It was such an incredible trip. Have you been?", 0),
        (users.get("alice@globepair.com"), users.get("bob@globepair.com"), "Not yet, but it's on my bucket list! Maybe we could plan something?", 1),
        (users.get("carol@globepair.com"), users.get("david@globepair.com"), "Hi David! 15 countries is impressive. Which was your favorite?", 0),
        (users.get("david@globepair.com"), users.get("carol@globepair.com"), "Hey Carol! Hard to pick but I loved Japan the most. The food, the culture...", 0),
        (users.get("david@globepair.com"), users.get("carol@globepair.com"), "You're a yoga instructor right? I could use some flexibility tips after all that traveling haha", 1),
        (users.get("emma@globepair.com"), users.get("frank@globepair.com"), "Hey Frank! What's the last movie you watched?", 0),
        (users.get("frank@globepair.com"), users.get("emma@globepair.com"), "Hey Emma! Just watched Interstellar again. Never gets old.", 0),
        (users.get("grace@globepair.com"), users.get("henry@globepair.com"), "A marine biologist in Mombasa! That sounds like a dream job.", 0),
        (users.get("henry@globepair.com"), users.get("grace@globepair.com"), "It really is! The ocean never ceases to amaze me. Do you like seafood?", 1),
        (users.get("alice@globepair.com"), users.get("david@globepair.com"), "David! I read your profile, fellow adventurer here!", 0),
        (users.get("bob@globepair.com"), users.get("emma@globepair.com"), "Hi Emma, I love your design portfolio. Very creative stuff!", 0),
    ]

    count = 0
    for from_id, to_id, content, is_read in sample_conversations:
        if from_id and to_id:
            cur.execute("""
                INSERT INTO message (from_user_id, to_user_id, content, is_read, created_at)
                VALUES (?, ?, ?, ?, ?)
            """, (from_id, to_id, content, is_read, now))
            count += 1

    conn.commit()
    print(f"  [OK] {count} sample messages inserted")


def insert_sample_favorites(conn):
    """Insert sample favorites for testing."""
    cur = conn.cursor()

    cur.execute("SELECT COUNT(*) FROM favorite")
    if cur.fetchone()[0] > 0:
        print("  [SKIP] Sample favorites already exist")
        return

    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    cur.execute("SELECT id, email FROM user WHERE is_admin = 0 ORDER BY id")
    users = {row[1]: row[0] for row in cur.fetchall()}

    pairs = [
        ("alice@globepair.com", "bob@globepair.com"),
        ("alice@globepair.com", "david@globepair.com"),
        ("bob@globepair.com", "alice@globepair.com"),
        ("bob@globepair.com", "emma@globepair.com"),
        ("carol@globepair.com", "david@globepair.com"),
        ("david@globepair.com", "carol@globepair.com"),
        ("david@globepair.com", "grace@globepair.com"),
        ("emma@globepair.com", "frank@globepair.com"),
        ("frank@globepair.com", "emma@globepair.com"),
        ("grace@globepair.com", "henry@globepair.com"),
        ("henry@globepair.com", "grace@globepair.com"),
        ("henry@globepair.com", "alice@globepair.com"),
    ]

    count = 0
    for user_email, target_email in pairs:
        user_id = users.get(user_email)
        target_id = users.get(target_email)
        if user_id and target_id:
            try:
                cur.execute("""
                    INSERT INTO favorite (user_id, favorite_user_id, created_at)
                    VALUES (?, ?, ?)
                """, (user_id, target_id, now))
                count += 1
            except sqlite3.IntegrityError:
                pass  # Duplicate, skip

    conn.commit()
    print(f"  [OK] {count} sample favorites inserted")


def insert_sample_payments(conn):
    """Insert sample completed payments for testing."""
    cur = conn.cursor()

    cur.execute("SELECT COUNT(*) FROM payment WHERE status = 'completed'")
    if cur.fetchone()[0] > 0:
        print("  [SKIP] Sample payments already exist")
        return

    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Premium payment for alice
    cur.execute("SELECT id FROM user WHERE email = ?", ("alice@globepair.com",))
    alice_id = cur.fetchone()

    if alice_id:
        cur.execute("""
            INSERT INTO payment (user_id, phone, amount, status, mpesa_receipt,
                                 checkout_request_id, merchant_request_id, reference,
                                 payment_type, created_at, completed_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            alice_id[0], "254711111111", 1500, "completed", "QJK3LR2P5V",
            "ws_CO_1234567890", "ws_CO_0987654321",
            "PREM_1_" + now, "premium", now, now,
        ))
        print("  [OK] Sample premium payment for Alice inserted")

    # Message payment for bob
    cur.execute("SELECT id FROM user WHERE email = ?", ("bob@globepair.com",))
    bob_id = cur.fetchone()
    cur.execute("SELECT id FROM user WHERE email = ?", ("carol@globepair.com",))
    carol_id = cur.fetchone()

    if bob_id and carol_id:
        cur.execute("""
            INSERT INTO messagepayment (user_id, phone, amount, currency, status, mpesa_receipt,
                                        checkout_request_id, merchant_request_id, reference,
                                        to_user_id, payment_method, expires_at, created_at, completed_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            bob_id[0], "254722222222", 200, "KES", "completed", "SBM7KL9MN3",
            "ws_CO_1111111111", "ws_CO_2222222222",
            "MSG_2_" + now, carol_id[0], "mpesa",
            (datetime.now() + timedelta(hours=24)).strftime("%Y-%m-%d %H:%M:%S"),
            now, now,
        ))
        print("  [OK] Sample message payment for Bob inserted")

    conn.commit()


def print_summary(conn):
    """Print a summary of what's in the database."""
    cur = conn.cursor()

    print()
    print("=" * 50)
    print("  DATABASE SUMMARY")
    print("=" * 50)

    tables = ["user", "message", "favorite", "payment", "messagepayment"]
    for table in tables:
        cur.execute(f"SELECT COUNT(*) FROM {table}")
        count = cur.fetchone()[0]
        print(f"  {table:<20} {count} rows")

    print()
    print("-" * 50)
    print("  USER ACCOUNTS")
    print("-" * 50)

    cur.execute("SELECT email, first_name, last_name, user_role, is_admin, status FROM user ORDER BY id")
    for row in cur.fetchall():
        role = "ADMIN" if row[4] else row[3]
        badge = "*" if row[4] else ("+" if row[3] == "premium" else "-")
        print(f"  [{badge}] {row[0]:<30} {row[1]} {row[2]:<15} {role:<10} {row[5]}")

    print()
    print("-" * 50)
    print("  LOGIN CREDENTIALS")
    print("-" * 50)
    print(f"  Admin:  {ADMIN_EMAIL} / {ADMIN_PASSWORD}")
    print(f"  User:   alice@globepair.com / alice123")
    print(f"  User:   bob@globepair.com / bob123")
    print(f"  User:   carol@globepair.com / carol123")
    print(f"  (all sample users use their first name as password)")
    print("=" * 50)


def main():
    print()
    print("=" * 50)
    print("  GlobePair - Database Setup")
    print("=" * 50)
    print()

    # Warn if database already exists
    if os.path.exists(DB_PATH):
        print(f"  [INFO] Database already exists: {DB_PATH}")
        print(f"  [INFO] Will skip existing records (safe to re-run)")
        print()

    # Connect and create tables
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")

    print("  Creating tables...")
    create_tables(conn)

    print()
    print("  Inserting admin user...")
    insert_admin(conn)

    print()
    print("  Inserting sample users...")
    insert_sample_users(conn)

    print()
    print("  Inserting sample messages...")
    insert_sample_messages(conn)

    print()
    print("  Inserting sample favorites...")
    insert_sample_favorites(conn)

    print()
    print("  Inserting sample payments...")
    insert_sample_payments(conn)

    print_summary(conn)

    conn.close()

    print()
    print(f"  Database saved to: {DB_PATH}")
    print()
    print("  NOTE: Update DB_PATH in config.php to point to 'globepair.db'")
    print("        Currently config.php uses 'globepair.sqlite'")
    print()


if __name__ == "__main__":
    main()
