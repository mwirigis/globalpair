<?php
/**
 * GlobePair - Configuration
 */

require __DIR__ . '/rb.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

date_default_timezone_set('Africa/Nairobi');

// Database Setup
define('DB_PATH', __DIR__ . '/globepair.db');
define('SITE_NAME', 'GlobePair - Find Your Perfect Match');
define('SITE_URL', 'https://globepair.com');
define('UPLOAD_DIR', __DIR__ . '/uploads/');
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_TYPES', ['image/jpeg', 'image/png', 'image/gif', 'image/webp']);

// ==================== PAYMENT CONFIGURATION ====================
define('MESSAGE_FEE_KES', 200);
define('MESSAGE_FEE_USD', 2);
define('PREMIUM_PRICE', 1500);

// ==================== M-PESA CONFIGURATION ====================
define('MPESA_PAYBILL', 'YOUR_PAYBILL_NUMBER');
define('MPESA_CONSUMER_KEY', 'YOUR_CONSUMER_KEY_HERE');
define('MPESA_CONSUMER_SECRET', 'YOUR_CONSUMER_SECRET_HERE');
define('MPESA_PASSKEY', 'YOUR_PASSKEY_HERE');
define('MPESA_SHORTCODE', 'YOUR_SHORTCODE_HERE');
define('MPESA_CALLBACK_URL', SITE_URL . '/index.php?action=mpesa_callback');
define('MPESA_SANDBOX', true);

// ==================== PAYPAL CONFIGURATION ====================
define('PAYPAL_CLIENT_ID', 'YOUR_PAYPAL_CLIENT_ID_HERE');
define('PAYPAL_CLIENT_SECRET', 'YOUR_PAYPAL_CLIENT_SECRET_HERE');
define('PAYPAL_MODE', 'sandbox');
define('PAYPAL_CURRENCY', 'USD');

// Admin Configuration
define('ADMIN_EMAIL', 'admin@globepair.com');

// Database Connection
try {
    R::setup('sqlite:' . DB_PATH);
    R::freeze(true);
    if (!R::testConnection()) {
        throw new Exception('Database connection failed');
    }
} catch (Exception $e) {
    die('Database Error: ' . $e->getMessage());
}

// Create uploads and logs directory
if (!is_dir(UPLOAD_DIR)) {
    mkdir(UPLOAD_DIR, 0755, true);
}
if (!is_dir(__DIR__ . '/logs')) {
    mkdir(__DIR__ . '/logs', 0755, true);
}