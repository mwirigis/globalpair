#!/usr/bin/env python3
"""
GlobePair - Project Scaffolder
Run this script to generate the blank file structure.
Usage: python3 setup.py
"""

import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

FOLDERS = [
    "uploads",
    "logs",
]

FILES = [
    "config.php",
    "helpers.php",
    "payments.php",
    "header.php",
    "footer.php",
    "index.php",
    "home.php",
    "login.php",
    "register.php",
    "payment_required.php",
    "payment_status.php",
    "dashboard.php",
    "discover.php",
    "view_profile.php",
    "chat.php",
    "favorites.php",
    "my_payments.php",
    "edit_profile.php",
    "premium.php",
    "admin.php",
]

def main():
    print("=" * 40)
    print("  GlobePair Project Scaffolder")
    print("=" * 40)
    print()

    created_folders = 0
    created_files = 0
    skipped = 0

    # Create folders
    for folder in FOLDERS:
        path = os.path.join(BASE_DIR, folder)
        if os.path.exists(path):
            print(f"  [SKIP] {folder}/ (already exists)")
            skipped += 1
        else:
            os.makedirs(path, exist_ok=True)
            # drop a .gitkeep so empty folders survive git
            gitkeep = os.path.join(path, ".gitkeep")
            open(gitkeep, "w").close()
            print(f"  [OK]   {folder}/")
            created_folders += 1

    print()

    # Create files
    for filename in FILES:
        path = os.path.join(BASE_DIR, filename)
        if os.path.exists(path):
            print(f"  [SKIP] {filename} (already exists)")
            skipped += 1
        else:
            open(path, "w").close()
            print(f"  [OK]   {filename}")
            created_files += 1

    print()
    print("-" * 40)
    print(f"  Folders created : {created_folders}")
    print(f"  Files created   : {created_files}")
    print(f"  Skipped         : {skipped}")
    print("-" * 40)
    print()
    print("  Done. Place rb.php in the root folder.")
    print("  Then fill in each .php file.")
    print()

if __name__ == "__main__":
    main()
