<?php
/**
 * GlobePair - Helper Functions
 */

function sanitize($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

function getCurrentUser() {
    return isset($_SESSION['user_id']) ? R::load('user', $_SESSION['user_id']) : null;
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    $user = getCurrentUser();
    return $user && $user->is_admin == 1;
}

function requireLogin() {
    if (!isLoggedIn()) {
        $_SESSION['redirect'] = $_SERVER['REQUEST_URI'];
        header('Location: ?action=login');
        exit;
    }
}

function requireAdmin() {
    if (!isAdmin()) {
        $_SESSION['error'] = 'Access denied. Admin only.';
        header('Location: ?action=home');
        exit;
    }
}

function generateCSRFToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verifyCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

function handlePhotoUpload($file, $user_id = null) {
    if (!isset($file) || $file['error'] !== UPLOAD_ERR_OK) {
        return null;
    }
    
    if ($file['size'] > MAX_FILE_SIZE) {
        return ['error' => 'File size must be less than 5MB'];
    }
    
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime_type = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    if (!in_array($mime_type, ALLOWED_TYPES)) {
        return ['error' => 'Invalid file type. Allowed: JPG, PNG, GIF, WebP'];
    }
    
    $extension = '';
    switch ($mime_type) {
        case 'image/jpeg': $extension = '.jpg'; break;
        case 'image/png': $extension = '.png'; break;
        case 'image/gif': $extension = '.gif'; break;
        case 'image/webp': $extension = '.webp'; break;
    }
    
    $filename = ($user_id ? 'user_' . $user_id : 'temp_' . uniqid()) . '_' . time() . $extension;
    $destination = UPLOAD_DIR . $filename;
    
    if (move_uploaded_file($file['tmp_name'], $destination)) {
        return 'uploads/' . $filename;
    }
    
    return ['error' => 'Failed to upload file'];
}

function canSendMessage($from_user, $to_user) {
    if ($from_user->user_role === 'premium' && $to_user->user_role === 'premium') {
        return true;
    }
    
    $payment = R::findOne('messagepayment', 'user_id = ? AND status = ? AND expires_at > ?', 
        [$from_user->id, 'completed', date('Y-m-d H:i:s')]);
    
    return (bool)$payment;
}

function initializeDatabase() {
    $admin = R::dispense('user');
    $admin->email = 'admin@globepair.com';
    $admin->password = password_hash('admin123', PASSWORD_BCRYPT);
    $admin->first_name = 'Admin';
    $admin->last_name = 'User';
    $admin->city = 'Nairobi';
    $admin->bio = 'Platform Administrator';
    $admin->birth_date = '1990-01-01';
    $admin->gender = 'other';
    $admin->user_role = 'premium';
    $admin->is_admin = 1;
    $admin->status = 'active';
    $admin->created_at = date('Y-m-d H:i:s');
    $admin->updated_at = date('Y-m-d H:i:s');
    R::store($admin);

    $users = [
        ['email' => 'alice@globepair.com', 'password' => password_hash('alice123', PASSWORD_BCRYPT), 'first_name' => 'Alice', 'last_name' => 'Johnson', 'city' => 'Nairobi', 'bio' => 'Adventure lover & coffee enthusiast. Looking for someone who enjoys outdoor activities and good conversations.', 'birth_date' => '1995-03-15', 'gender' => 'female', 'user_role' => 'premium', 'status' => 'active'],
        ['email' => 'bob@globepair.com', 'password' => password_hash('bob123', PASSWORD_BCRYPT), 'first_name' => 'Bob', 'last_name' => 'Smith', 'city' => 'Nairobi', 'bio' => 'Software engineer & photography hobbyist. Love capturing beautiful moments.', 'birth_date' => '1993-07-22', 'gender' => 'male', 'user_role' => 'premium', 'status' => 'active'],
        ['email' => 'carol@globepair.com', 'password' => password_hash('carol123', PASSWORD_BCRYPT), 'first_name' => 'Carol', 'last_name' => 'Williams', 'city' => 'Mombasa', 'bio' => 'Yoga instructor & beach lover. Life is better at the beach!', 'birth_date' => '1998-11-08', 'gender' => 'female', 'user_role' => 'regular', 'status' => 'active'],
        ['email' => 'david@globepair.com', 'password' => password_hash('david123', PASSWORD_BCRYPT), 'first_name' => 'David', 'last_name' => 'Brown', 'city' => 'Kisumu', 'bio' => 'Entrepreneur & traveler. Been to 15 countries and counting.', 'birth_date' => '1991-05-30', 'gender' => 'male', 'user_role' => 'regular', 'status' => 'active'],
        ['email' => 'emma@globepair.com', 'password' => password_hash('emma123', PASSWORD_BCRYPT), 'first_name' => 'Emma', 'last_name' => 'Davis', 'city' => 'Nairobi', 'bio' => 'Graphic designer & art lover. Creativity is my superpower.', 'birth_date' => '1996-09-14', 'gender' => 'female', 'user_role' => 'premium', 'status' => 'active'],
        ['email' => 'frank@globepair.com', 'password' => password_hash('frank123', PASSWORD_BCRYPT), 'first_name' => 'Frank', 'last_name' => 'Miller', 'city' => 'Nakuru', 'bio' => 'Gym enthusiast & movie buff. Looking for my co-star in life.', 'birth_date' => '1994-02-20', 'gender' => 'male', 'user_role' => 'regular', 'status' => 'active'],
        ['email' => 'grace@globepair.com', 'password' => password_hash('grace123', PASSWORD_BCRYPT), 'first_name' => 'Grace', 'last_name' => 'Wanjiku', 'city' => 'Nairobi', 'bio' => 'Teacher by day, chef by night. Love trying new recipes.', 'birth_date' => '1997-06-12', 'gender' => 'female', 'user_role' => 'premium', 'status' => 'active'],
        ['email' => 'henry@globepair.com', 'password' => password_hash('henry123', PASSWORD_BCRYPT), 'first_name' => 'Henry', 'last_name' => 'Ochieng', 'city' => 'Mombasa', 'bio' => 'Marine biologist. The ocean is my second home.', 'birth_date' => '1992-12-05', 'gender' => 'male', 'user_role' => 'regular', 'status' => 'active'],
    ];

    foreach ($users as $userData) {
        $user = R::dispense('user');
        foreach ($userData as $key => $value) {
            $user->$key = $value;
        }
        $user->is_admin = 0;
        $user->created_at = date('Y-m-d H:i:s');
        $user->updated_at = date('Y-m-d H:i:s');
        R::store($user);
    }
}